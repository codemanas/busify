<?php
/**
 * Plugin Name: Busify Elementor Widgets Bundle
 * Description: Widgets bundle compatibile for busify theme only
 * Plugin URI:  https://codemanas.com
 * Version:     1.0.0
 * Author:      Deepen Bajracharya
 * Author URI:  https://deepenbajracharya.com.np/
 * Text Domain: busify-elementor-bundle
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BUSIFY_ELEMENTOR_BUNDLE_URI', plugin_dir_url( __FILE__ ) );
define( 'BUSIFY_ELEMENTOR_BUNDLE_DIR', plugin_dir_path( __FILE__ ) );

if ( ! class_exists( 'Busify_Elementor_Bundle' ) ) {
	require BUSIFY_ELEMENTOR_BUNDLE_DIR . 'includes/class-busify-elementor.php';
}
