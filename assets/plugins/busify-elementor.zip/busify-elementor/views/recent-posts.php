<div class="row">
	<?php
	foreach ( $posts as $post ) {
		$post_author_id = get_post_field( 'post_author', $post->ID );
		$user           = get_userdata( $post_author_id );

		$date   = $settings['display_date'] === "yes" ? "<strong>" . date( 'F d, Y', strtotime( $post->post_date ) ) . "</strong>" : false;
		$author = $settings['display_author'] === "yes" ? "<strong> By " . $user->display_name . "</strong>" : false;
		$image  = $settings['featured_image'] === "yes" ? '<div class="busify-recent-post-thumbnail">' . get_the_post_thumbnail( $post->ID, 'medium' ) . '</div>' : false;
		?>
        <div class="col-md-4">
            <div class="busify-elementor-module-post busify-elementor-module-post-<?php echo $post->ID; ?>">
				<?php echo $image; ?>
                <div class="busify-recent-post-contents">
                    <h5 class="busify-recent-post-title"><a href="<?php echo get_permalink( $post->ID ); ?>"><?php echo $post->post_title; ?></a></h5>
                    <div class="busify-template-tags"><?php echo $date; ?><?php echo $author; ?></div>
                    <div class="busify-recent-post-excerpt"><?php echo get_the_excerpt(); ?></div>
                    <a href="<?php echo get_permalink( $post->ID ); ?>" class="mt-1 btn btn-busify-primary btn-customizing-read-more">Read More</a>
                </div>
            </div>
        </div>
		<?php
	}
	?>
</div>
