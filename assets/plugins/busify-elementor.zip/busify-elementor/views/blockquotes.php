<?php
$block_text = $settings['blockquote_text'];
if ( ! empty( $block_text ) ) {
	?>
    <div class="busify-blockquote-wrapper">
        <blockquote><?php echo $block_text; ?></blockquote>
    </div>
	<?php
}
