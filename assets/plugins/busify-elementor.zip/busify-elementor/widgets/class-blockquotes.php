<?php

namespace BusifyElementorBoostrap\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Busify_Blockquotes' ) ) {

	/**
	 * Elementor Hello World
	 *
	 * Elementor widget for hello world.
	 *
	 * @since 1.0.0
	 */
	class Busify_Blockquotes extends Widget_Base {
		/**
		 * Retrieve the widget name.
		 *
		 * @since 1.0.0
		 *
		 * @access public
		 *
		 * @return string Widget name.
		 */
		public function get_name() {
			return 'busify-blockquotes';
		}

		/**
		 * Retrieve the widget title.
		 *
		 * @since 1.0.0
		 *
		 * @access public
		 *
		 * @return string Widget title.
		 */
		public function get_title() {
			return __( 'Blockquotes', 'busify-elementor-bundle' );
		}

		/**
		 * Retrieve the widget icon.
		 *
		 * @since 1.0.0
		 *
		 * @access public
		 *
		 * @return string Widget icon.
		 */
		public function get_icon() {
			return 'eicon-editor-quote';
		}

		/**
		 * Retrieve the list of categories the widget belongs to.
		 *
		 * Used to determine where to display the widget in the editor.
		 *
		 * Note that currently Elementor supports only one category.
		 * When multiple categories passed, Elementor uses the first one.
		 *
		 * @since 1.0.0
		 *
		 * @access public
		 *
		 * @return array Widget categories.
		 */
		public function get_categories() {
			return [ 'basic' ];
		}

		/**
		 * Retrieve the list of scripts the widget depended on.
		 *
		 * Used to set scripts dependencies required to run the widget.
		 *
		 * @since 1.0.0
		 *
		 * @access public
		 *
		 * @return array Widget scripts dependencies.
		 */
		public function get_script_depends() {
			return [ 'busify-elementor-bundle' ];
		}

		/**
		 * Register the widget controls.
		 *
		 * Adds different input fields to allow the user to change and customize the widget settings.
		 *
		 * @since 1.0.0
		 *
		 * @access protected
		 */
		protected function _register_controls() {
			$this->start_controls_section( 'section_content', [
				'label' => __( 'Block Quotes', 'busify-elementor-bundle' ),
			] );
			$this->add_control( 'blockquote_text', [
				'label' => __( 'Text', 'busify-elementor-bundle' ),
				'type'  => Controls_Manager::TEXTAREA,
			] );
			$this->end_controls_section();
		}

		/**
		 * Render the widget output on the frontend.
		 *
		 * Written in PHP and used to generate the final HTML.
		 *
		 * @since 1.0.0
		 *
		 * @access protected
		 */
		protected function render() {
			$settings = $this->get_settings_for_display();
			require_once BUSIFY_ELEMENTOR_BUNDLE_DIR . 'views/blockquotes.php';
		}

		/**
		 * Render shortcode widget as plain content.
		 *
		 * Override the default behavior by printing the shortcode instead of rendering it.
		 *
		 * @since 1.0.0
		 * @access public
		 */
		public function render_plain_content() {
			// In plain mode, render without shortcode
			echo $this->get_settings( 'shortcode' );
		}

		/**
		 * Render the widget output in the editor.
		 *
		 * Written as a Backbone JavaScript template and used to generate the live preview.
		 *
		 * @since 1.0.0
		 *
		 * @access protected
		 */
		protected function _content_template() {
		}
	}
}

