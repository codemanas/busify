<?php

namespace BusifyElementorBoostrap;

/**
 * Main Plugin class
 *
 * @since 1.0.0
 * @author CodeManas
 */
class Busify_Elementor_Boostrap {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function __construct() {
		// Register widget scripts
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ], 99 );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
	}

	/**
	 * widget_scripts
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function widget_styles() {
		wp_register_style( 'busify-elementor-bundle', BUSIFY_ELEMENTOR_BUNDLE_URI . 'assets/busify-elementor-bundle.css' );
		wp_enqueue_style( 'busify-elementor-bundle' );
	}

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function include_widgets_files() {
		require_once( BUSIFY_ELEMENTOR_BUNDLE_DIR . '/widgets/class-recent-posts.php' );
		require_once( BUSIFY_ELEMENTOR_BUNDLE_DIR . '/widgets/class-blockquotes.php' );
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Busify_Recent_Posts() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Busify_Blockquotes() );
	}
}

// Instantiate Plugin Class
Busify_Elementor_Boostrap::instance();